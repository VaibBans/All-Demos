package com.cg.jpacrud.service;

import com.capgemini.jpacrud.dto.Author;
import com.cg.jpacrud.dao.AuthorDao;
import com.cg.jpacrud.dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService {

	public AuthorDao authorDao;
	public AuthorServiceImpl() {
		authorDao = new AuthorDaoImpl();
	}

	@Override
	public void addAuthor(Author author) {
		authorDao.beginTransaction();
		authorDao.addAuthor(author);
		authorDao.commitTransaction();
	}

	@Override
	public void updateAuthor(Author author) {
		authorDao.beginTransaction();
		authorDao.updateAuthor(author);
		authorDao.commitTransaction();

	}

	@Override
	public void removeAuthor(Author author) {
		authorDao.beginTransaction();
		authorDao.removeAuthor(author);
		authorDao.commitTransaction();
	}

	@Override
	public Author getAuthorById(int id) {
		Author author = authorDao.getAuthorById(id);
		return author;
	}
}
