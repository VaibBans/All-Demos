package com.cg.jpacrud.client;

import com.capgemini.jpacrud.dto.Author;
import com.cg.jpacrud.service.AuthorService;
import com.cg.jpacrud.service.AuthorServiceImpl;

public class Client {

	public static void main(String[] args) {
		AuthorService service = new AuthorServiceImpl();
		Author author = new Author();
		author.setAuthorId(1008);
		author.setFirstName("Alan");
		author.setMiddleName("T");
		author.setLastName("Turing");
		author.setPhoneNo(9889665214L);

		//service.addAuthor(author);
		/*author.setMiddleName("T");
		service.updateAuthor(author);*/
	
		//Author author1 = new Author();
		
		/*author = service.getAuthorById(1004);
		System.out.println("Author Id: "+author.getAuthorId()
				+"\nAuthor Name: "+author.getFirstName()+" "+
				author.getMiddleName()+" "+author.getLastName()+
				"\nPhone Number: "+author.getPhoneNo());	*/
		
		author = service.getAuthorById(1007);
		service.removeAuthor(author);
		System.out.println("EOP");
	}

}
