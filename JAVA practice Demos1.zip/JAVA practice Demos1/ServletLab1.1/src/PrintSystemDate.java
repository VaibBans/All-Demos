import java.time.LocalDate;


public class PrintSystemDate {

	public static void main(String[] args) {
		LocalDate sysDate = LocalDate.now();
		System.out.println(sysDate);

	}

}
