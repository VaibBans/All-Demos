package com.cg.spring.injection;

import java.util.ArrayList;
import java.util.List;

public class SBU {
	int sbuCode;
	String sbuName;
	String sbuHead;
	EmployeeBean emp;
	List<EmployeeBean> empList = new ArrayList<EmployeeBean>();
		
	public List<EmployeeBean> getEmpList() {
		return empList;
	}
	public void setEmpList(List<EmployeeBean> empList) {
		this.empList = empList;
	}
	/*public EmployeeBean getEmp() {
		return emp;
	}
	public void setEmp(EmployeeBean emp) {
		this.emp = emp;
	}*/
	public int getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	@Override
	public String toString() {
		
		return "SBU Details\nSBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName
				+ ", sbuHead=" + sbuHead + "\nEmployee Details\n empList="
				+ empList + "]";
	}
	
	
	
}