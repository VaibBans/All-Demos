package com.cg.spring.dao;

import java.util.HashMap;

import com.cg.spring.bean.EmployeeBean;

public interface IEmployeeDao {
	public HashMap<Integer, EmployeeBean> getEmpDetails(int empId);
}
