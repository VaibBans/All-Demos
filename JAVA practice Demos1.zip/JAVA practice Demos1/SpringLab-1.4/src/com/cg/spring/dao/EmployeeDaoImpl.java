package com.cg.spring.dao;

import java.util.HashMap;

import com.cg.spring.bean.EmployeeBean;
import com.cg.spring.staticdb.EmployeeDB;

public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public HashMap<Integer, EmployeeBean> getEmpDetails(int empId) {
		HashMap<Integer, EmployeeBean> empDetails = new HashMap<>();
				empDetails = EmployeeDB.getEmpMap();
		return empDetails;
	}

}
