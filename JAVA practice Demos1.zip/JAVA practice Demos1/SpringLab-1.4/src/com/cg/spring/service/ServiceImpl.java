package com.cg.spring.service;

import java.util.HashMap;

import com.cg.spring.bean.EmployeeBean;
import com.cg.spring.dao.EmployeeDaoImpl;
import com.cg.spring.dao.IEmployeeDao;

public class ServiceImpl implements IService {

	public ServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	IEmployeeDao dao = new EmployeeDaoImpl();
	@Override
	public HashMap<Integer, EmployeeBean> getEmpDetails(int empId) {
		
		return dao.getEmpDetails(empId);
	}

}
