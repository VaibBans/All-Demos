package com.cg.spring.service;

import java.util.HashMap;

import com.cg.spring.bean.EmployeeBean;

public interface IService {
	HashMap<Integer, EmployeeBean> getEmpDetails(int empId);
}
