package com.cg.spring.staticdb;

import java.util.HashMap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.bean.EmployeeBean;

public class EmployeeDB {

	public EmployeeDB() {
		
	}
	static HashMap<Integer, EmployeeBean> empMap = getEmpMap();
	static{
	if(empMap==null){
		empMap = new HashMap<>();
		ApplicationContext ctx = new ClassPathXmlApplicationContext("user.xml");
		EmployeeBean emp1 = (EmployeeBean)ctx.getBean("employee");
		EmployeeBean emp2 = (EmployeeBean)ctx.getBean("employee1");
		empMap.put(100,emp1);
		empMap.put(101,emp2);	
	}
}
	public static HashMap<Integer, EmployeeBean> getEmpMap() {
		return empMap;
	}
	public static void setEmpMap(HashMap<Integer, EmployeeBean> empMap) {
		EmployeeDB.empMap = empMap;
	}
}
