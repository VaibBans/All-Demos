package com.cg.spring.client;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.spring.bean.EmployeeBean;
import com.cg.spring.service.IService;
import com.cg.spring.service.ServiceImpl;

public class Client {

	public static void main(String[] args) {
		IService service = new ServiceImpl();
		System.out.println("Enter Employee Id");
		Scanner sc = new Scanner(System.in);
		int empId = sc.nextInt();
		HashMap<Integer, EmployeeBean> empDetails = service.getEmpDetails(empId);
//		System.out.println(empDetails);
		System.out.println("Employee Info");
		System.out.println("Employee ID    :"+empDetails.get(empId).getEmpId());
		System.out.println("Employee NAME    :"+empDetails.get(empId).getEmpName());
		System.out.println("Employee SALARY    :"+empDetails.get(empId).getSalary());

	}

}
