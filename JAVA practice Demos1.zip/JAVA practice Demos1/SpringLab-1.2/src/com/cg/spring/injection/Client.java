package com.cg.spring.injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("user.xml");
		EmployeeBean emp = (EmployeeBean) ctx.getBean("employee");
		System.out.println(emp);
	}

}
