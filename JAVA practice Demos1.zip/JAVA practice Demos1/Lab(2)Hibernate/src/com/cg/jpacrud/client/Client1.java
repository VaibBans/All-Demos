package com.cg.jpacrud.client;

import java.util.List;

import com.cg.jpacrud.dao.BookDao1;
import com.cg.jpacrud.dao.BookDaoImpl1;
import com.cg.jpacrud.dto.Book1;

public class Client1 {

	public static void main(String[] args) {
		BookDao1 dao = new BookDaoImpl1();
		
		List<Book1>books = dao.getAllBooks();
		for(Book1 book:books){
			System.out.println(book);
		}
	}
}