package com.cg.jpacrud.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="authors_masters")
public class Author1 implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="id")
	private int authorId;
	private String authorName;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="authors")
	private Set<Book1> books = new HashSet<>();
	
	public Set<Book1> getBooks() {
		return books;
	}
	public void setBooks(Set<Book1> books) {
		this.books = books;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Book [authorId=" + authorId + ", authorName=" + authorName
				+ "]";
	}
}