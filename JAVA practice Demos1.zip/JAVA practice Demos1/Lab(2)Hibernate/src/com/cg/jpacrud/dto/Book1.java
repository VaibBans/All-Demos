package com.cg.jpacrud.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "books_masters")
public class Book1 implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String isbn;
	private String bookName;
	private float price;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "authors_books", joinColumns = {@JoinColumn(name = "isbn")},inverseJoinColumns = {@JoinColumn(name = "id")})
	
	private Set<Author1> authors = new HashSet<>();

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Set<Author1> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author1> authors) {
		this.authors = authors;
	}

	@Override
	public String toString() {
		return "Book1 [isbn=" + isbn + ", bookName=" + bookName + ", price="
				+ price + ", authors=" + authors + "]";
	}	
}