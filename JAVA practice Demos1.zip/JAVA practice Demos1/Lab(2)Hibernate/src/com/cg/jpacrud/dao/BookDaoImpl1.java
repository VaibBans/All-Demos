package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.jpacrud.dto.Book1;

public class BookDaoImpl1 implements BookDao1 {

	private EntityManager entityManager;
	public BookDaoImpl1() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public List<Book1> getAllBooks() {
		String qry = "SELECT book FROM Book1 book";
		TypedQuery<Book1> query = entityManager.createQuery(qry,Book1.class);
		List<Book1> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public List<Book1> getBooksByAuthorName(String author) {
		String qry = "Select book from Book1 book where authorname = :pauthor";
		TypedQuery<Book1> query = entityManager.createQuery(qry,Book1.class);
		query.setParameter("pauthor", author);
		List<Book1> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public List<Book1> getBooksByPrice(float low,float high) {
		String qry = "Select book from Book book where book.price between :low AND :high"; 
		TypedQuery<Book1> query = entityManager.createQuery(qry, Book1.class);
		query.setParameter("low", low);
		query.setParameter("high", high);
		List<Book1> bookList = query.getResultList();
		return bookList;
	}
	
	
}
