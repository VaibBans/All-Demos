package com.cg.jpacrud.dao;

import java.util.List;

import com.cg.jpacrud.dto.Book1;

public interface BookDao1 {
	public abstract List<Book1> getAllBooks();

	public abstract List<Book1> getBooksByAuthorName(String author);

	public abstract List<Book1> getBooksByPrice(float low,float high);

}
