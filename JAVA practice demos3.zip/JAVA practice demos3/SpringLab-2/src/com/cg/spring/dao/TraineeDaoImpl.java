
package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.bean.TraineeBean;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;

	TraineeBean trainee=null;
	
	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public TraineeBean retrieveTrainee(int traineeId) {
		String qry = "Select trainee from TraineeBean trainee where traineeId =:pTraineeId";
		TypedQuery<TraineeBean> query = entityManager.createQuery(qry, TraineeBean.class);
		query.setParameter("pTraineeId",traineeId);
		TraineeBean trainee = query.getSingleResult();
		return trainee;
	}

	@Override
	public List<TraineeBean> retrieveAllTrainees() {
		String qry = "Select trainee from TraineeBean trainee";
		TypedQuery<TraineeBean> query =  entityManager.createQuery(qry,TraineeBean.class);
		List<TraineeBean> traineeList = query.getResultList();
		return traineeList;
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) {
		trainee = entityManager.find(TraineeBean.class, traineeId);
		entityManager.remove(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public TraineeBean updateTrainee(TraineeBean trainee) {
		entityManager.merge(trainee);
		return trainee;
	}

	@Override
	public TraineeBean viewTraineeById(int traineeId) {
		String qry = "Select trainee from TraineeBean trainee where traineeId=:pTraineeId";
		TypedQuery<TraineeBean> query = entityManager.createQuery(qry, TraineeBean.class);
		query.setParameter("pTraineeId", traineeId);
		TraineeBean trainee = query.getSingleResult();
		return trainee;
	}
	
}