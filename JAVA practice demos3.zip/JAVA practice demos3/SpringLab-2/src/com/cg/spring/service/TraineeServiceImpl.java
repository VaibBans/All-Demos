package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.TraineeBean;
import com.cg.spring.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao dao;

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		return dao.addTrainee(trainee);
	}

	@Override
	public TraineeBean retrieveTrainee(int traineeId) {
		return dao.retrieveTrainee(traineeId);
	}

	@Override
	public List<TraineeBean> retrieveAllTrainees() {
		return dao.retrieveAllTrainees();
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) {
		return dao.deleteTrainee(traineeId);
	}

	@Override
	public TraineeBean updateTrainee(TraineeBean trainee) {
		return dao.updateTrainee(trainee);
	}

	@Override
	public TraineeBean viewTraineeById(int traineeId) {
		return dao.viewTraineeById(traineeId);
	}
}