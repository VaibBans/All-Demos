import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.truckbooking.bean.TruckBean;


public class TruckTestCase {
	
	private static TruckBean truckBean = null;

	@Before
	public void setUp() throws Exception {
		truckBean = new TruckBean();
	}

	@After
	public void tearDown() throws Exception {
		truckBean = null;
	}

	@Test
	public void testGetBookingIdNumber() {
		truckBean.setDestination("Mumbai");
		assertEquals("Mumbai", truckBean.getDestination());
	}
	@Test
	public void testGetTruckID() {
		truckBean.setTruckID(1001);
		assertEquals(1001, truckBean.getTruckID());
	}
	
	@Test
	public void testGetAvailableNos() {
		truckBean.setAvailableNos(2);
		assertEquals(2, truckBean.getAvailableNos());
	}
	@Test
	public void testGetOrigin() {
		truckBean.setOrigin("ABCD");
		assertEquals("ABCD", truckBean.getOrigin());
	}
	@Test
	public void testGetTruckType() {
		truckBean.setTruckType("ABCD");
		assertEquals("ABCD", truckBean.getTruckType());
	}

	@Test
	public void testGetDestination() {
		truckBean.setDestination("XYZ");
		assertEquals("XYZ", truckBean.getDestination());
	}
}
