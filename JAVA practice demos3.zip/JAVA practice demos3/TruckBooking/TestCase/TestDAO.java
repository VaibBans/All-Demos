import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.dao.TruckDao;


public class TestDAO {
	private TruckDao truckDao = null;
	@Before
	public void setUp() throws Exception {
		truckDao = new TruckDao();
	}

	@After
	public void tearDown() throws Exception {
		truckDao = null;
	}

	@Test
	public void testInsert() throws BookingException {
		BookingBean bookingBean = new BookingBean("A124563",9856321470L,1002,2,LocalDate.parse("2017-12-25"));
		truckDao.bookTrucks(bookingBean);
	}
	@Test
	public void testUpadte() throws BookingException {
		int truckId=1002,noOfTrucks=2;
		truckDao.updateTrucks(truckId, noOfTrucks);
	}

}
