import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.truckbooking.bean.BookingBean;


public class BookingTestCase {
	
	private static BookingBean bookingBean = null;

	@Before
	public void setUp() throws Exception {
		bookingBean = new BookingBean();
	}

	@After
	public void tearDown() throws Exception {
		bookingBean = null;
	}

	@Test
	public void testGetBookingIdNumber() {
		bookingBean.setBookingID(12345);
		assertEquals(12345, bookingBean.getBookingID());
	}
	@Test
	public void testGetCustomerId() {
		bookingBean.setCustId("A123456");
		assertEquals("A123456", bookingBean.getCustId());
	}
	@Test
	public void testGetTruckId() {
		bookingBean.setTruckId(1001);
		assertEquals(1001, bookingBean.getTruckId());
	}
	
	@Test
	public void testGetNoOfTrucks() {
		bookingBean.setNoOfTrucks(2);
		assertEquals(2, bookingBean.getNoOfTrucks());
	}
	@Test
	public void testGetCustMobile() {
		bookingBean.setCustMobile(1245789632);
		assertEquals(1245789632, bookingBean.getCustMobile());
	}

}
