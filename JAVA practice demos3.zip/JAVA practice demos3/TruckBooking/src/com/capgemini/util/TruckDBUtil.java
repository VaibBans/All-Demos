package com.capgemini.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class TruckDBUtil {

private static Connection connPurchase;
	
	public static Connection createConnection() throws SQLException
	{
		ResourceBundle resOracle = ResourceBundle.getBundle("oracle");
		String url = resOracle.getString("url");
		String username = resOracle.getString("username");
		String password = resOracle.getString("password");
		
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connPurchase = DriverManager.getConnection(url,username,password);		
		return connPurchase;
	}
	public static void closeConnection() throws SQLException
	{
		if(connPurchase!=null)
		{
			connPurchase.close();
		}
	}
}
