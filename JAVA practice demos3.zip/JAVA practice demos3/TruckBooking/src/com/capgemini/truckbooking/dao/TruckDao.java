package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.util.TruckDBUtil;

public class TruckDao implements ITruckDao {
	private static Logger logger = Logger.getLogger(com.capgemini.truckbooking.dao.TruckDao.class);
	public TruckDao() {
		// TODO Auto-generated constructor stub
	}
	BookingBean bookingBean = new BookingBean();
	@Override
	public int getBookingId() throws BookingException {
		int bookingId=0;
		Connection connTruck = null;
		int status=0;
		PreparedStatement pstTruck = null;
		PreparedStatement pstTruck1 = null;
		try{
		connTruck = TruckDBUtil.createConnection();
		
		String oracle = new String("INSERT INTO BOOKINGDETAILS(BOOKINGID) VALUES(BOOKING_ID_SEQ.NEXTVAL)");
		pstTruck = connTruck.prepareStatement(oracle);
		status = pstTruck.executeUpdate();
		String sql3 = new String("SELECT BOOKINGID FROM BOOKINGDETAILS");
		pstTruck1 = connTruck.prepareStatement(sql3);
		ResultSet rs = pstTruck1.executeQuery();
		while(rs.next()){
			bookingId = rs.getInt(1);
		}
		
	}catch(SQLException se){
		se.printStackTrace();
	}
		return bookingId;
	}
	
	// Retrieving Truck Details
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		ResultSet rs=null;
		ArrayList<TruckBean> listTruckBean = null;
		TruckBean truckBean = null;
		try{
			listTruckBean = new ArrayList<TruckBean>();
			
			Connection connTruck = null;
			PreparedStatement pstTruck = null;
			String oracle = new String("SELECT * FROM TRUCKDETAILS");
			connTruck = TruckDBUtil.createConnection();
			pstTruck = connTruck.prepareStatement(oracle);
			rs = pstTruck.executeQuery();
			while(rs.next())
			{
				truckBean = new TruckBean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),
						rs.getInt(5),rs.getInt(6));
				listTruckBean.add(truckBean);
				/*System.out.println(rs.getInt(1)+"     "+rs.getString(2)+"    "+rs.getString(3)+"    "+rs.getString(4)
						+"    "+rs.getInt(5)+"    "+rs.getInt(6));*/
			}
			logger.info("View Successfull");
		}catch(SQLException se){
			logger.error("Enter valid Customer Id to view Truck Details");
			throw new BookingException("Truck Details cannot be displayed");
		}
		return listTruckBean;
		
	}

	public int selectTruckNumber(int truckId)throws BookingException{
		int[] truck = new int[15];
		int count=0;
		Connection connTruck = null;
		PreparedStatement pstTruck = null;
		try{
		connTruck = TruckDBUtil.createConnection();
		int i=0;
		ResultSet rs = null;
		String sql = new String("SELECT TRUCKID FROM TRUCKDETAILS WHERE TRUCKID=?");
		pstTruck=connTruck.prepareStatement(sql);
		pstTruck.setInt(1,truckId);
		rs = pstTruck.executeQuery();
		while(rs.next())
		{
			truck[i] = rs.getInt(1);
			i++;
		}
		for(i=0;i<15;i++){	 
			
			if(truckId==truck[i]){
				count++;
			}
		}
		logger.info("Entered truck id is valid");
		}
		catch(SQLException se){
			logger.error("Enter Valid Truck Id");
			throw new BookingException("Truck Id is not present");
		}
		return count;
	}
	public int availNosOfTrucks(int noOfTrucks,int truckId) throws BookingException{
		int availNoOfTrucks=0,upTrucks=0;
		String sql2 = new String("SELECT AVAILABLENOS FROM TRUCKDETAILS WHERE TRUCKID=?");
		Connection connTruck = null;
		try{
		connTruck = TruckDBUtil.createConnection();
		PreparedStatement pstTruck = null;
		pstTruck = connTruck.prepareStatement(sql2);
		pstTruck.setInt(1, truckId);
		ResultSet rs = pstTruck.executeQuery();
		while(rs.next()){
		availNoOfTrucks = rs.getInt(1);
		logger.info("Booking number of Trucks is valid");
		}
		if(availNoOfTrucks-noOfTrucks>=0){
			upTrucks++;
		}
		}catch(SQLException se){
			logger.error("Wrong number of trucks");
			throw new BookingException("Wrong number of trucks");
		}
		return upTrucks;
	}
	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {

		int status = 0;
		Connection connTruck = null;
		PreparedStatement pstTruck = null;
		try{
			String oracle = new String("INSERT INTO BOOKINGDETAILS(BOOKINGID,CUSTID,CUSTMOBILE,TRUCKID,NOOFTRUCKS,DATEOFTRANSPORT) VALUES(BOOKING_ID_SEQ.NEXTVAL,?,?,?,?,?)");
			connTruck = TruckDBUtil.createConnection();
			pstTruck = connTruck.prepareStatement(oracle);
			pstTruck.setString(1,bookingBean.getCustId());
			pstTruck.setLong(2, bookingBean.getCustMobile());
			pstTruck.setInt(3,bookingBean.getTruckId());
			pstTruck.setInt(4,bookingBean.getNoOfTrucks());
			LocalDate dt1 = bookingBean.getDateOTransport();
			Date dt = Date.valueOf(dt1);
			pstTruck.setDate(5,dt);
			
			status = pstTruck.executeUpdate();
			logger.info("Record inserted successfully with Customer Id: "+bookingBean.getCustId());
		}catch(SQLException se)
		{
			logger.error(se.getMessage());
			se.printStackTrace();
			throw new BookingException("Record not inserted",se);
		}
		finally
		{
			try
			{
				TruckDBUtil.closeConnection();
			}
			catch(SQLException se)
			{
				throw new BookingException("Problems in Closing Connection",se);
			}
		}
		return status;
	}

	@Override
	public int updateTrucks(int truckId, int noOfTrucks) throws BookingException {
		String sql1="";
		int rs=0;
		Connection connTruck = null;
		PreparedStatement pstTruck = null;
		try{
		sql1 = new String("UPDATE TRUCKDETAILS SET AVAILABLENOS=AVAILABLENOS-? WHERE TRUCKID=?");
			connTruck = TruckDBUtil.createConnection();
			pstTruck = connTruck.prepareStatement(sql1);
			pstTruck.setInt(1, noOfTrucks);
			pstTruck.setInt(2,truckId);
			rs = pstTruck.executeUpdate();
		}
		catch(SQLException se){
			throw new BookingException("No of trucks not updated.");
		}
		return rs;
}
}
