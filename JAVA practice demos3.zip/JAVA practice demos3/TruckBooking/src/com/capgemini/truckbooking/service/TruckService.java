package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;

public class TruckService implements ITruckService {

	BookingBean bookingBean = new BookingBean();
	ITruckDao truckDAO = new TruckDao();
	public TruckService() {
		
	}

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		return(truckDAO.retrieveTruckDetails());
		
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		return (truckDAO.bookTrucks(bookingBean));
	}

	@Override
	public int updateTrucks(int truckId, int noOfTruckToBook)throws BookingException {
		return (truckDAO.updateTrucks(truckId, noOfTruckToBook));
	}

	@Override
	public int availNosOfTrucks(int noOfTrucks, int truckId)
			throws BookingException {
		return (truckDAO.availNosOfTrucks(noOfTrucks, truckId));
	}

	
}
