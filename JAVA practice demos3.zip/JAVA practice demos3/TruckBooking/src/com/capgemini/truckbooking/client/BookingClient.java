package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;


public class BookingClient {
//	private static Logger logger = Logger.getLogger(com.capgemini.truckbooking.dao.TruckDao.class);
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TruckBean truckBean = new TruckBean();
		BookingBean bookingBean = new BookingBean();
		String dateOfTran;
		LocalDate dt=null;
		List<TruckBean> printTruckDetails = null;
		TruckDao truckDao = new TruckDao();
		ITruckService truckService = new TruckService();
		System.out.println("Enter your choice: "
				+ "\n1.  Book Trucks"+"\n2.  Exit");
		int choice = sc.nextInt();
		int i=0;
		try{
			switch (choice) {
			case 1:System.out.print("Enter Customer ID: ");
			String custId = sc.next();
			if(custId.matches("^[A-Z]{1}[0-9]{2,6}$"))
			{
				System.out.println("TruckId"+"  TruckType      "+"Origin"+"  Destination"
						+"  Charge"+"  AvailableNos.");
				printTruckDetails  = truckService.retrieveTruckDetails();
				Iterator<TruckBean> printTruckDetailsIt = printTruckDetails.iterator();
				while(printTruckDetailsIt.hasNext()){
					System.out.println(printTruckDetailsIt.next());
				}
				
			}
			else{
				System.out.println("Enter valid Customer Id"); //Validation of customer id
				break;
			}
			System.out.print("Enter TruckId: ");  //Validation of truck id
			int truckId = sc.nextInt();
				try{
				if(truckDao.selectTruckNumber(truckId)>0)
				{
				try{
				System.out.println("Enter date of transportation in dd-MM-yyyy format");
				dateOfTran = sc.next();
				DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				dt = LocalDate.parse(dateOfTran,format);
				}catch(DateTimeParseException dtpe){
					System.out.println("Date Format should be dd-MM-yyyy");
				}
				if(dt.compareTo(LocalDate.now())>=0){
				System.out.print("Enter number of trucks: ");   //Validation of number of trucks
				int noOfTrucks = sc.nextInt();
				if(truckService.availNosOfTrucks(noOfTrucks, truckId)>0){
						System.out.print("Enter Customer Mobile: ");
						String mobile = sc.next();
						if(mobile.matches("^[0-9]{0,10}$")&&mobile.length()==10){  //Validation of Mobile Number
							long custMobile = Long.parseLong(mobile);
							bookingBean = new BookingBean(custId,custMobile,truckId,noOfTrucks,dt);
							System.out.println("Booking is Confirmed for booking id: "+truckDao.getBookingId());	
							truckService.retrieveTruckDetails();
							int sts = truckService.bookTrucks(bookingBean);
							if(sts==1){
								truckService.updateTrucks(truckId, noOfTrucks);
								System.out.println("Record Inserted Successfully");
							}
							else{
								System.out.println("Record Not Inserted");
							}
						}
						else{
							throw new BookingException("Enter valid mobile number");
							
						}
					}
					else{
						throw new BookingException("Booking number of Trucks must be less than Available numbers.");			
					}
				}
				else
				{
					throw new BookingException("Enter Date greater than current date");					
				}
				}
				else{
					throw new BookingException("Enter valid truck id");
				}
				}catch(BookingException be){
					System.out.println(be.getMessage());
				}
				break;
			case 2: System.out.println("You are out of the application."); 
					System.out.println("Thank You.");
				break;
		}
	
		}catch(BookingException be)
		{
		System.out.println(be.getMessage());
	}
}
}
